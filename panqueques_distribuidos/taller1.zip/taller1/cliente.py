#!/usr/bin/env python3

import socket

class clientSocket:
    def __init__(self):
        self.HOST = "127.0.0.1"  # The server's hostname or IP address
        self.PORT = 65430  # The port used by the server

    def sendQuery(self):
        numero, numeros = "",""
        while True:
            while numero.isnumeric() or numero == "":
                numero = input("ingrese un numero: ")
                if numero.isnumeric():
                    numeros += numero
                    numeros += "+"

            numeros = numeros[:-1]

            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((self.HOST, self.PORT))
                s.sendall(numeros.encode('utf-8'))
                data = s.recv(1024)

            print(f"Received {data!r}")
            numero = ""
            numeros = ""

if __name__ == "__main__":
    mysocket = clientSocket()
    mysocket.sendQuery()