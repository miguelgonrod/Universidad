#!/usr/bin/env python3

import socket
import random

class calcSocket:
    def __init__(self):
        self.HOST = "127.0.0.1"  # Standard loopback interface address (localhost)
        self.MYPORT = 65430  # Port to listen on (non-privileged ports are > 1023)
        self.HOSTPORT = [65433, 65435]
        self.servidorNumber = 1
    
    def checkServers(self):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind((self.HOST, self.MYPORT))
            while True:
                s.listen()
                conn, addr = s.accept()
                with conn:
                    print(f"Connected by {addr}")
                    data = conn.recv(1024)
                    print(data)
                    if data:
                        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as h:
                            self.servidorNumber = random.randint(0,1)
                            try:
                                h.connect((self.HOST, self.HOSTPORT[self.servidorNumber]))
                                h.sendall(data)
                                data = h.recv(1024)
                            except:
                                try:
                                    h.connect((self.HOST, self.HOSTPORT[not self.servidorNumber]))
                                    h.sendall(data)
                                    data = h.recv(1024)
                                except:
                                    data = eval(data)
                                    data = str(data).encode('utf-8')

                        conn.sendall(data)


if __name__ == "__main__":
    mysocket = calcSocket()
    calcSocket.checkServers()